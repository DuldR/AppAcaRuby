require_relative 'super_useful'

puts "'five' == #{convert_to_int('5')}"

feed_me_a_fruit

sam = BestFriend.new('Clown', 5, 'Smokin dope')

sam.talk_about_friendship
sam.do_friendstuff
sam.give_friendship_bracelet
