class Player
    def get_answer
        print "Enter a letter: "
        user_input = gets.chomp

        return user_input
    end

end