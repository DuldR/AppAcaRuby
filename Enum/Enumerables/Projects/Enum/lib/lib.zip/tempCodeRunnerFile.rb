
def add(arr)
    inB = ""
    returnArr = []

    arr.each do |ele|
        returnArr << ele
    end

    returnArr
end

butts = ["a", "b", "c"]